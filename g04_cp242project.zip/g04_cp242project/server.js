const express = require('express');
const session = require('express-session');
const path = require('path');

const authController = require('./controllers/authController');
const accountController = require('./controllers/accountController');
const productController = require('./controllers/productController');
const shopController = require('./controllers/shopController');
const transactionController = require('./controllers/transactionController');

const app = express();
const port = 3000;

// ตั้งค่า session
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false
}));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Login and Register Page
app.get('/login', authController.showLoginPage);
app.post('/login', authController.loginUser);

app.get('/register', authController.showRegisterPage);
app.post('/register', authController.registerUser);

app.post('/logout', authController.authenticate, authController.logoutUser);

// == For user ==
app.get('/', authController.authenticate, productController.showHomePage);
app.post('/buy/:productId', authController.authenticate, transactionController.buyProduct);

// === For admin ===
app.get('/admin', authController.authenticate, authController.isAdmin, authController.showAdminPage);
// Manage Nodes
app.get('/admin/manage-product', authController.authenticate, authController.isAdmin, productController.showManageProductPage);
app.get('/admin/manage-product/:id/edit', productController.showManageProductPage);
app.post('/admin/add-product', authController.authenticate, authController.isAdmin, productController.addProduct);
app.post('/admin/update-product/:id', productController.updateProduct);
app.post('/admin/delete-product/:id', authController.authenticate, authController.isAdmin, productController.deleteProduct);

app.get('/admin/manage-shop', authController.authenticate, authController.isAdmin, shopController.showManageShopPage);
app.get('/admin/manage-shop/:id/edit', shopController.showManageShopPage);
app.post('/admin/add-shop', authController.authenticate, authController.isAdmin, shopController.addShop);
app.post('/admin/update-shop/:id', shopController.updateShop);
app.post('/admin/delete-shop/:id', authController.authenticate, authController.isAdmin, shopController.deleteShop);

app.get('/admin/manage-account', authController.authenticate, authController.isAdmin, accountController.showManageAccountPage);
app.post('/admin/delete-account/:id', authController.authenticate, authController.isAdmin, accountController.deleteAccount);

// === Error Handling ===
// 404 handler
app.use((req, res, next) => {
    res.status(404).render('error', {
        status: 404,
        message: 'Page Not Found'
    });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(err.status || 500).render('error', {
        status: err.status || 500,
        message: err.message || 'Internal Server Error'
    });
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
