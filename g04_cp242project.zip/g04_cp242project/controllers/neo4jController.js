const driver = require('../models/models');

exports.authNeo4j = async (req, res, next) => {
    const session = driver.session();
    try {
        await session.run('RETURN 1');
        res.render('index', { status: 'Connected to Neo4j successfully!' });
    } catch (err) {
        next(err);
    } finally {
        await session.close();
    }
}

// CREATE
exports.createNode = async (label, properties) => {
    const session = driver.session();
    try {
        const cypherQuery = `CREATE (n:${label} $properties) RETURN n`;
        await session.run(cypherQuery, { properties });
    } finally {
        await session.close();
    }
};

// READ
exports.readNodes = async (label) => {
    const session = driver.session();
    try {
        const result = await session.run(`MATCH (n:${label}) RETURN n`);
        return result.records.map(record => record.get('n').properties);
    } finally {
        await session.close();
    }
};

// READ BY ID
exports.readNodesById = async (label, id) => {
    const session = driver.session();
    try {
        const result = await session.run(`MATCH (n:${label} {id: $id}) RETURN n`, { id });
        return result.records.length > 0 ? result.records[0].get('n').properties : null;
    } finally {
        await session.close();
    }
};

// READ NODES BY MULTIPLE RELATIONSHIPS 
exports.readNodesByRelationship = async (startNodeType, startNodeId, relationshipTypes) => {
    const session = driver.session();
    try {
        const relationshipPattern = relationshipTypes
            .map(type => `-[r:${type}]->(b)`)
            .join(' ');

        const query = `
            MATCH (a:${startNodeType} {id: $startNodeId}) ${relationshipPattern}
            RETURN a, r, b
        `;

        const result = await session.run(query, { startNodeId });

        return result.records.map(record => ({
            startNode: record.get('a').properties,
            relationship: record.get('r').properties,
            endNode: record.get('b').properties
        }));
    } finally {
        await session.close();
    }
};

// UPDATE
exports.updateNode = async (label, id, properties) => {
    const session = driver.session();
    try {
        const cypherQuery = `MATCH (n:${label} {id: $id}) SET n += $properties RETURN n`;
        await session.run(cypherQuery, { id, properties });
    } finally {
        await session.close();
    }
};

// DELETE
exports.deleteNode = async (label, properties) => {
    const session = driver.session();
    try {
        const cypherQuery = `MATCH (n:${label} {${Object.keys(properties).map(key => `${key}: $${key}`).join(', ')}}) DELETE n`;
        await session.run(cypherQuery, properties);
    } finally {
        await session.close();
    }
};

// CREATE RELATIONSHIP
exports.createRelationship = async (startNodeType, startNodeId, relationshipType, endNodeType, endNodeId) => {
    const session = driver.session();
    try {
        const result = await session.run(
            `MATCH (a:${startNodeType} {id: $startNodeId}), (b:${endNodeType} {id: $endNodeId})
             CREATE (a)-[:${relationshipType}]->(b)
             RETURN a, b`,
            {
                startNodeId,
                endNodeId,
                relationshipType
            }
        );
        return result;
    } catch (err) {
        throw new Error('Error creating relationship: ' + err.message);
    } finally {
        await session.close();
    }
};

// READ RELATIONSHIP
exports.getRelationships = async (label, id) => {
    const session = driver.session();
    try {
        const query = `
            MATCH (a:${label} {id: $id})-[r]->(b)
            RETURN type(r) as type, properties(r) as props, labels(b) as targetLabels, b.id as targetId
        `;
        const result = await session.run(query, { id });
        return result.records.map(record => ({
            type: record.get('type'),
            properties: record.get('props'),
            to: {
                labels: record.get('targetLabels'),
                id: record.get('targetId')
            }
        }));
    } finally {
        await session.close();
    }
};

// DELETE RELATIONSHIP
exports.deleteRelationship = async (fromLabel, fromId) => {
    const session = driver.session();
    try {
        const query = `
            MATCH (a:${fromLabel} {id: $fromId})-[r]->(b)
            DELETE r
        `;
        await session.run(query, { fromId });
    } finally {
        await session.close();
    }
};

// MANGAE RELATIONSHIP 
exports.createOrUpdateBuyRelationship = async (accountId, productId) => {
    const session = driver.session();
    try {
        const query = `
            MATCH (a:Account {id: $accountId}), (p:Product {id: $productId})
            MERGE (a)-[r:BOUGHT]->(p)
            ON CREATE SET r.count = 1, r.lastBought = datetime()
            ON MATCH SET r.count = r.count + 1, r.lastBought = datetime()
        `;
        await session.run(query, { accountId, productId });
    } finally {
        await session.close();
    }
};

// Manage Product And Shop
exports.getShopNameById = async (shopId) => {
    const session = driver.session();
    try {
        const cypherQuery = `MATCH (s:Shop {id: $shopId}) RETURN s.shopName AS shopName`;
        const result = await session.run(cypherQuery, { shopId });
        if (result.records.length > 0) {
            return result.records[0].get('shopName');
        }
        return null;
    } finally {
        await session.close();
    }
};

exports.updateProductCount = async (productId, newCount) => {
    const session = driver.session();
    try {
        const result = await session.run(
            `MATCH (p:Product {id: $productId})
             SET p.productCounts = $newCount
             RETURN p`,
            { productId, newCount }
        );
        return result;
    } catch (err) {
        throw new Error('Error updating product count: ' + err.message);
    } finally {
        await session.close();
    }
};

exports.getRecommendedProducts = async (accountId) => {
    const session = driver.session();
    try {
        const query = `
            MATCH (a:Account {id: $accountId})-[b:BOUGHT]->(p:Product)
            WITH p.productCategory AS category, SUM(b.count) AS totalCount
            ORDER BY totalCount DESC
            LIMIT 1

            MATCH (rec:Product)
            WHERE rec.productCategory = category
            RETURN rec
            ORDER BY rec.productCounts ASC
            LIMIT 4
        `;
        const result = await session.run(query, { accountId });

        return result.records.map(record => {
            const product = record.get('rec').properties;
            return {
                id: product.id,
                productName: product.productName,
                productPrice: product.productPrice.toNumber?.() ?? product.productPrice,
                productCategory: product.productCategory,
                productCounts: product.productCounts.toNumber?.() ?? product.productCounts,
                productTags: product.productTags,
                productImageUrl: product.productImageUrl,
                shopId: product.shopId
            };
        });
    } finally {
        await session.close();
    }
};

exports.getRecommendedShopProducts = async (accountId) => {
    const session = driver.session();

    try {
        const result = await session.run(
            `
            MATCH (a:Account {id: $accountId})-[b:BOUGHT]->(p:Product)
            WITH p.shopId AS shopId, SUM(b.count) AS totalCount
            ORDER BY totalCount DESC
            LIMIT 1
            WITH shopId

            MATCH (prod:Product {shopId: shopId})
            RETURN prod
            ORDER BY prod.productCounts ASC
            LIMIT 4
            `,
            { accountId }
        );

        return result.records.map(record => {
            const product = record.get('prod').properties;
            return {
                id: product.id,
                productName: product.productName,
                productPrice: product.productPrice.toNumber?.() ?? product.productPrice,
                productCategory: product.productCategory,
                productCounts: product.productCounts.toNumber?.() ?? product.productCounts,
                productTags: product.productTags,
                productImageUrl: product.productImageUrl,
                shopId: product.shopId,
            };
        });

    } finally {
        await session.close();
    }
};

exports.getPurchaseCountByCategory = async (accountId) => {
    const session = driver.session();
    const query = `
        MATCH (a:Account {id: $accountId})-[b:BOUGHT]->(p:Product)
        RETURN p.productCategory AS category, SUM(b.count) AS totalCount
    `;
    const result = await session.run(query, { accountId });
    session.close();
    return result.records.map(record => ({
        category: record.get('category'),
        count: record.get('totalCount').toInt()
    }));
};

exports.getPurchaseCountByShop = async (accountId) => {
    const session = driver.session();
    const query = `
        MATCH (a:Account {id: $accountId})-[b:BOUGHT]->(p:Product)-[:FROM]->(s:Shop)
        RETURN s.shopName AS shop, SUM(b.count) AS totalCount
    `;
    const result = await session.run(query, { accountId });
    session.close();
    return result.records.map(record => ({
        shop: record.get('shop'),
        count: record.get('totalCount').toInt()
    }));
};



