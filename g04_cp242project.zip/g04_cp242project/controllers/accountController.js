const neo4jController = require('./neo4jController');

exports.showManageAccountPage = async (req, res, next) => {
    try {
        const accounts = await neo4jController.readNodes('Account');

        const accountEmail = req.params.email;
        let account = null;
        let isEdit = false;

        if (accountEmail) {
            account = accounts.find(a => a.email === accountEmail);
            isEdit = true;
        }

        res.render('manage-account', {
            message: req.query.message || null,
            accounts,
            isEdit,
            account
        });
    } catch (err) {
        next(err);
    }
};

// สำหรับ login: หา account โดย email และ password
exports.findAccountByEmailAndPassword = async (email, password) => {
    const accounts = await neo4jController.readNodes('Account');
    return accounts.find(acc => acc.email === email && acc.password === password);
};

// สำหรับ register: สร้าง account ใหม่ ถ้าไม่ซ้ำ
exports.createAccountDirect = async ({ username, email, role, password }) => {
    const accounts = await neo4jController.readNodes('Account');
    const duplicate = accounts.find(acc => acc.email === email || acc.username === username);

    if (duplicate) {
        throw new Error('Email or Username already exists');
    }

    const id = Date.now().toString();

    return await neo4jController.createNode('Account', {
        id,
        username,
        email,
        role,
        password
    });
};

// DELETE
exports.deleteAccount = async (req, res, next) => {
    const { id } = req.params;

    try {
        await neo4jController.deleteRelationship('Account', id);

        await neo4jController.deleteNode('Account', { id });

        res.redirect('/admin/manage-account?message=Account deleted successfully!');
    } catch (err) {
        const message = encodeURIComponent('Error to delete account: ' + err.message);
        res.redirect(`/admin/manage-account?message=${message}`);
    }
};

