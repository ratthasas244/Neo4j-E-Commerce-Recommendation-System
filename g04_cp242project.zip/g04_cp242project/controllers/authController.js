const accountController = require('./accountController');

exports.showLoginPage = (req, res) => res.render('login', { error: null });
exports.showRegisterPage = (req, res) => res.render('register', { error: null });
exports.showAdminPage = (req, res) => res.render('admin', { error: null });

exports.authenticate = (req, res, next) => {
    if (req.session && req.session.user) {
        next();
    } else {
        res.redirect('/login');
    }
};

exports.isAdmin = (req, res, next) => {
    if (req.session.user?.role === 'Admin') return next();
    res.status(403).send('Access denied');
};

// LOGIN
exports.loginUser = async (req, res, next) => {
    const { email, password } = req.body;

    try {
        const user = await accountController.findAccountByEmailAndPassword(email, password);

        if (!user) {
            return res.render('login', { error: 'Invalid credentials' });
        }

        // เก็บข้อมูลใน session รวมถึง accountId
        req.session.user = {
            accountId: user.id, 
            email: user.email,
            username: user.username,
            role: user.role
        };

        if (user.role === 'Admin') {
            return res.redirect('/admin');
        }

        res.redirect('/');
    } catch (err) {
        next(err);
    }
};

// REGISTER
exports.registerUser = async (req, res, next) => {
    const { username, email, password, confirmPassword, role } = req.body;

    if (password !== confirmPassword) {
        return res.render('register', { error: 'Passwords do not match' });
    }

    try {
        await accountController.createAccountDirect({ username, email, role, password });
        res.redirect('/login');
    } catch (err) {
        res.render('register', { error: err.message });
    }
};

// LOGOUT
exports.logoutUser = (req, res) => {
    req.session.destroy(err => {
        if (err) return next(err);
        res.redirect('/login');
    });
};
