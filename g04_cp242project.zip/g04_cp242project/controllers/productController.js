const neo4jController = require('./neo4jController');

exports.showManageProductPage = async (req, res, next) => {
    try {
        const products = await neo4jController.readNodes('Product');
        const shops = await neo4jController.readNodes('Shop'); // Fetching Shops

        const productId = req.params.id;
        let product = null;
        let isEdit = false;
        let shopId = req.query.shopId || ''; // รับค่า shopId จาก query parameter

        if (productId) {
            product = products.find(p => p.id === productId);
            isEdit = true;
        }

        res.render('manage-product', {
            message: req.query.message || null,
            products,
            isEdit,
            product,
            shops, // Passing shops to the view
            shopId // ส่งค่า shopId ไปยัง view
        });
    } catch (err) {
        next(err);
    }
};

exports.showHomePage = async (req, res, next) => {
    try {
        const products = await neo4jController.readNodes('Product');

        const productsWithShopName = await Promise.all(products.map(async (product) => {
            const shopName = await neo4jController.getShopNameById(product.shopId);
            return { ...product, shopName };
        }));

        const accountId = req.session.user?.accountId;

        let recommendProducts = [];
        let shopProducts = [];

        if (accountId) {
            recommendProducts = await neo4jController.getRecommendedProducts(accountId);
            shopProducts = await neo4jController.getRecommendedShopProducts(accountId);

            recommendProducts.sort((a, b) => a.productCounts - b.productCounts);
            shopProducts.sort((a, b) => a.productCounts - b.productCounts);

            recommendProducts = await Promise.all(recommendProducts.map(async (product) => {
                const shopName = await neo4jController.getShopNameById(product.shopId);
                return { ...product, shopName };
            }));

            shopProducts = await Promise.all(shopProducts.map(async (product) => {
                const shopName = await neo4jController.getShopNameById(product.shopId);
                return { ...product, shopName };
            }));
        }

        const message = req.session.message;
        delete req.session.message;

        const categorySummary = await neo4jController.getPurchaseCountByCategory(accountId);
        const shopSummary = await neo4jController.getPurchaseCountByShop(accountId);
        
        res.render('index', {
            products: productsWithShopName,
            accountId,
            message,
            recommendProducts,
            shopProducts,
            categorySummary,
            shopSummary
        });
    } catch (err) {
        next(err);
    }
};

// CREATE PRODUCT
exports.addProduct = async (req, res, next) => {
    const { productName, productPrice, productCategory, productDescription, productCounts, productTags, productImageUrl, shopId } = req.body;

    try {
        const id = Date.now().toString(); // แบบง่าย

        // เพิ่มข้อมูลสินค้าพร้อม shopId
        await neo4jController.createNode('Product', {
            id,
            productName,
            productPrice: parseFloat(productPrice),
            productCategory,
            productDescription,
            productCounts,
            productTags,
            productImageUrl,
            shopId // เพิ่ม shopId ในข้อมูลสินค้า
        });

        await neo4jController.createRelationship('Product', id, 'FROM', 'Shop', shopId);

        // ถ้าสำเร็จ redirect พร้อมส่ง success message
        res.redirect('/admin/manage-product?message=Product added successfully!');
    } catch (err) {
        // ถ้า error redirect พร้อมส่ง error message
        const message = encodeURIComponent('Error to add product: ' + err.message);
        res.redirect(`/admin/manage-product?message=${message}`);
    }
};

// UPDATE PRODUCT
exports.updateProduct = async (req, res, next) => {
    const { id } = req.params;
    const { productName, productPrice, productCategory, productDescription, productCounts, productTags, productImageUrl, shopId } = req.body;

    try {
        // ดึงข้อมูลสินค้าจาก Neo4j
        const product = await neo4jController.readNodes('Product', id);

        // ถ้าไม่พบสินค้า, ให้ error กลับ
        if (!product) {
            const message = encodeURIComponent('Product not found!');
            return res.redirect(`/admin/manage-product?message=${message}`);
        }

        // ตรวจสอบ shopId เก่า
        const oldShopId = product.shopId;

        // อัปเดตข้อมูลสินค้าในฐานข้อมูล
        await neo4jController.updateNode('Product', id, {
            productName,
            productPrice: parseFloat(productPrice),
            productCategory,
            productDescription,
            productCounts,
            productTags,
            productImageUrl,
            shopId // อัปเดต shopId ด้วย
        });

        // ถ้า shopId เปลี่ยนแปลง, ลบความสัมพันธ์เก่าและสร้างใหม่
        if (oldShopId !== shopId) {
            // ลบความสัมพันธ์เก่าก่อน
            await neo4jController.deleteRelationship('Product', id);

            // สร้างความสัมพันธ์ใหม่กับ shopId ใหม่
            await neo4jController.createRelationship('Product', id, 'FROM', 'Shop', shopId);
        }

        // Redirect กลับพร้อมข้อความสำเร็จ
        res.redirect('/admin/manage-product?message=Product updated successfully!');
    } catch (err) {
        // ส่งข้อความผิดพลาดกลับ
        const message = encodeURIComponent('Error to update product: ' + err.message);
        res.redirect(`/admin/manage-product?message=${message}`);
    }
};

// DELETE PRODUCT
exports.deleteProduct = async (req, res, next) => {
    const { id } = req.params;

    try {
        // ลบความสัมพันธ์ระหว่าง Product และ Shop ก่อน
        await neo4jController.deleteRelationship('Product', id);

        // ลบสินค้าใน Neo4j โดยใช้ id
        await neo4jController.deleteNode('Product', { id });

        // ส่งข้อความ success กลับไปที่หน้า manage-product
        res.redirect('/admin/manage-product?message=Product deleted successfully!');
    } catch (err) {
        // ส่งข้อความ error หากเกิดข้อผิดพลาด
        const message = encodeURIComponent('Error to delete product: ' + err.message);
        res.redirect(`/admin/manage-product?message=${message}`);
    }
};
