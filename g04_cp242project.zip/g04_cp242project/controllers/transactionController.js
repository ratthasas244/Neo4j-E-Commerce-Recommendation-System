const neo4jController = require('./neo4jController');

exports.buyProduct = async (req, res) => {
    const accountId = req.body.accountId;
    const productId = req.body.productId;

    try {
        const accountExists = await neo4jController.readNodesById('Account', accountId);
        const productExists = await neo4jController.readNodesById('Product', productId);

        if (!accountExists) {
            req.session.message = { type: 'danger', text: 'Account not found' };
            return res.redirect('/');
        }
        if (!productExists) {
            req.session.message = { type: 'danger', text: 'Product not found' };
            return res.redirect('/');
        }

        const productCounts = productExists.productCounts;
        if (productCounts <= 0) {
            req.session.message = { type: 'warning', text: 'Product is out of stock' };
            return res.redirect('/');
        }

        await neo4jController.updateProductCount(productId, productCounts - 1);
        await neo4jController.createOrUpdateBuyRelationship(accountId, productId);

        req.session.message = { type: 'success', text: 'Purchase recorded successfully!' };
        return res.redirect('/');
    } catch (error) {
        console.error('Error during purchase:', error);
        req.session.message = { type: 'danger', text: 'An error occurred during purchase.' };
        return res.redirect('/');
    }
};
