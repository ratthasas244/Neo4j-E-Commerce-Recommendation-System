const neo4jController = require('./neo4jController');

exports.showManageShopPage = async (req, res, next) => {
    try {
        const shops = await neo4jController.readNodes('Shop');

        const shopId = req.params.id;
        let shop = null;
        let isEdit = false;

        if (shopId) {
            shop = shops.find(s => s.id === shopId);
            isEdit = true;
        }

        res.render('manage-shop', {
            message: req.query.message || null,
            shops,
            isEdit,
            shop
        });
    } catch (err) {
        next(err);
    }
};

// CREATE SHOP
exports.addShop = async (req, res, next) => {
    const { shopName, shopAddress, shopPhone } = req.body;

    try {
        const id = Date.now().toString();

        await neo4jController.createNode('Shop', {
            id,
            shopName,
            shopAddress,
            shopPhone
        });

        res.redirect('/admin/manage-shop?message=Shop added successfully!');
    } catch (err) {
        const message = encodeURIComponent('Error to add shop: ' + err.message);
        res.redirect(`/admin/manage-shop?message=${message}`);
    }
};

// UPDATE SHOP
exports.updateShop = async (req, res, next) => {
    const { id } = req.params;
    const { shopName, shopAddress, shopPhone } = req.body;

    try {
        await neo4jController.updateNode('Shop', id, {
            shopName,
            shopAddress,
            shopPhone
        });

        res.redirect('/admin/manage-shop?message=Shop updated successfully!');
    } catch (err) {
        const message = encodeURIComponent('Error to update shop: ' + err.message);
        res.redirect(`/admin/manage-shop?message=${message}`);
    }
};

// DELETE SHOP
exports.deleteShop = async (req, res, next) => {
    const { id } = req.params;
    try {
        await neo4jController.deleteNode('Shop', { id });

        res.redirect('/admin/manage-shop?message=Shop deleted successfully!');
    } catch (err) {
        const message = encodeURIComponent('Error to delete shop: ' + err.message);
        res.redirect(`/admin/manage-shop?message=${message}`);
    }
};
